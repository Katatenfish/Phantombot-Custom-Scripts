﻿namespace Funbit.Ets.Telemetry.Server.Setup
{
    public enum SetupStatus
    {
        Uninstalled,
        Installed,
        Failed
    }
}