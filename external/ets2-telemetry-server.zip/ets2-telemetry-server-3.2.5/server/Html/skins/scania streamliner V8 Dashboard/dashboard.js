﻿var _skinConfig;
Funbit.Ets.Telemetry.Dashboard.prototype.initialize = function (skinConfig, utils) {
    //
    // skinConfig - a copy of the skin configuration from config.json
    // utils - an object containing several utility functions (see skin tutorial for more information)
    //

    // this function is called before everything else, 
    // so you may perform any DOM or resource initializations / image preloading here

	_skinConfig = skinConfig;
	
    utils.preloadImages([
        /* 'images/bg-off.jpg', 'images/bg-on.jpg' */
    ]);

	
    // return to menu by a click
    /* $(document).getElementById('exit').on('click', function () {
        window.history.back();
    }); */
}

Funbit.Ets.Telemetry.Dashboard.prototype.filter = function (data, utils) {
    //
    // data - telemetry data JSON object
    // utils - an object containing several utility functions (see skin tutorial for more information)
    //

    // This filter is used to change telemetry data 
    // before it is displayed on the dashboard.
    // You may convert km/h to mph, kilograms to tons, etc.
	data.electricOn = data.truck.electricOn;
	data.hasJob = data.trailer.attached;
			
	data.warnblinkerLeftOn = data.truck.blinkerLeftOn;
	data.warnblinkerRightOn = data.truck.blinkerRightOn;
	
	data.tacho_licht_an = data.truck.lightsParkingOn;
	data.Tachonadel_klein_blau = data.truck.lightsParkingOn;
	data.Tachonadel_klein_rot = data.truck.lightsParkingOn;
	data.Tachonadel_gross = data.truck.lightsParkingOn;
	
	data.hintergrund_beleuchtung = data.truck.lightsDashboardValue;
	if (data.hintergrund_beleuchtung === 0) {
		$('.hintergrundbeleuchtung').css('opacity', 0.4);
	} else {
		$('.hintergrundbeleuchtung').css('opacity', data.truck.lightsDashboardValue);
	}

    // round truck speed
    data.truck.speedRounded = Math.abs(data.truck.speed > 0
        ? Math.floor(data.truck.speed)
        : Math.round(data.truck.speed));

    // other examples:
    // convert kg to t
    data.trailer.mass = (data.trailer.mass / 1000.0) + 't';
    // format odometer data as: 00000.0
    data.truck.odometer = utils.formatFloat(data.truck.odometer, 1);
    // convert gear to readable format
    data.truck.gear = data.truck.gear > 0 ? 'D' + data.truck.gear : (data.truck.gear < 0 ? 'R' : 'N');
    // convert rpm to rpm * 100
    data.truck.engineRpm = data.truck.engineRpm / 100;
	
	//schaden in Textform
	data.truck.motor_prozent = utils.formatFloat(data.truck.wearEngine*100, 0) + '%';
    data.truck.getriebe_prozent = utils.formatFloat(data.truck.wearTransmission*100, 0) + '%';
    data.truck.fahrerhaus_prozent = utils.formatFloat(data.truck.wearCabin*100, 0) + '%';
    data.truck.fahrwerk_prozent = utils.formatFloat(data.truck.wearChassis*100, 0) + '%'; 
    data.truck.raeder_prozent = utils.formatFloat(data.truck.wearWheels*100, 0) + '%';
	
    // calculate wear
    var wearSumPercent = data.truck.wearEngine * 100 +
        data.truck.wearTransmission * 100 +
        data.truck.wearCabin * 100 +
        data.truck.wearChassis * 100 +
        data.truck.wearWheels * 100;
    wearSumPercent = Math.min(wearSumPercent, 100);
	data.truck.gesamtschaden = Math.round(wearSumPercent);
    data.trailer.wear = Math.round(data.trailer.wear * 100) + ' %';
	
	//schaden in Textform
	data.truck.motor_prozent = utils.formatFloat(data.truck.wearEngine*100, 0);
    data.truck.getriebe_prozent = utils.formatFloat(data.truck.wearTransmission*100, 0);
    data.truck.fahrerhaus_prozent = utils.formatFloat(data.truck.wearCabin*100, 0);
    data.truck.fahrwerk_prozent =  utils.formatFloat(data.truck.wearChassis*100, 0); 
    data.truck.raeder1_prozent = utils.formatFloat(data.truck.wearWheels*100, 0);
    data.truck.raeder2_prozent = utils.formatFloat(data.truck.wearWheels*100, 0);
    data.truck.raeder3_prozent = utils.formatFloat(data.truck.wearWheels*100, 0);
    data.truck.raeder4_prozent = utils.formatFloat(data.truck.wearWheels*100, 0);
    data.truck.gesamtschaden_prozent =  Math.round(wearSumPercent);
	
	
	/*Berechnen des Inspektions intervalls*/
	data.inspektion = _skinConfig.inspektion;
	data.truck.gesamtschaden = Math.round(wearSumPercent);
	data.truck.schaden_km = (data.inspektion / 100) * data.truck.gesamtschaden_prozent;
	data.naechste_inspektion = data.inspektion - data.truck.schaden_km;
	
	if (data.naechste_inspektion > 0){
		data.truck.inspektion = 'in &nbsp;' + data.naechste_inspektion + 'km';
	} else{
		data.truck.inspektion = 'Bring the truck for inspection!';
	}
	
	
	/*Temperatur Berechnunen*/
	data.truck.oilTemperature_text = utils.formatFloat(data.truck.oilTemperature, 1);
	data.truck.brakeTemperature_text = utils.formatFloat(data.truck.brakeTemperature, 1);
	data.truck.waterTemperature_text = utils.formatFloat(data.truck.waterTemperature, 1);
	
	// Display Uhrzeit erstellen
	var aktuelle_uhrzeit = new Date(data.game.time)
	
	data.aktuelle_stunde = aktuelle_uhrzeit.getUTCHours();
	if(data.aktuelle_stunde < 10){data.aktuelle_stunde = '0' + data.aktuelle_stunde;} 
	
	data.aktuelle_minute = aktuelle_uhrzeit.getUTCMinutes();
	if(data.aktuelle_minute < 10){data.aktuelle_minute = '0' + data.aktuelle_minute;} 
	
	data.uhrzeit =  data.aktuelle_stunde + ':' + data.aktuelle_minute;
	
	// truck-fuelAverageConsumption berechnen
	data.truck.kraftstoffverbrauch = data.truck.fuelAverageConsumption * 100;
	
	
	if (data.truck.fuelAverageConsumption * 100 < 130){
		 data.fuelAverageConsumption = utils.formatFloat(data.truck.fuelAverageConsumption * 100, 1);
		 data.oberes_progr_feld_kraftstoffverbrauch_text = utils.formatFloat(data.truck.fuelAverageConsumption * 100, 1);
		 data.verbrauch = utils.formatFloat(data.truck.fuelAverageConsumption, 0);
		 data.kraftstoffverbrauch_tot = utils.formatFloat(data.truck.fuelAverageConsumption * 100, 1);
	}
	else {
		data.fuelAverageConsumption = 'Is being computed';
		data.oberes_progr_feld_kraftstoffverbrauch_text = '';
		data.truck.fuelAverageConsumption = 0 ;
	}
	
	
	data.fuelAverageConsumption = utils.formatFloat(data.truck.fuelAverageConsumption, 1);
	
	data.waterTemperature_zahl = data.truck.waterTemperature;
	
	//retarder icon aktivierung
	data.retarderICON = data.truck.retarderBrake > 0 ? true : false;
	
	//Tempomat
	data.intelligenterTempomat = _skinConfig.intelligenterTempomat;
	data.tempomat = data.truck.cruiseControlSpeed;
	
	if (data.truck.cruiseControlSpeed > 0){
		data.truck.cruiseControlSpeed = data.truck.cruiseControlSpeed;
		data.tempomat_bergab = data.truck.cruiseControlSpeed + data.intelligenterTempomat;
	} else{
		data.truck.cruiseControlSpeed = '--';
		data.tempomat_bergab = '--';
	}
		
	//Systemdruck ausgabe als zahl
	data.systemdruck = data.truck.airPressure
	data.brems_kreislauf_1 = utils.formatFloat(data.systemdruck / 10, 1); 
	data.brems_kreislauf_2 = utils.formatFloat(data.systemdruck / 10, 1); 
	
	// truck truck-odometer
	data.truck.odometer = utils.formatFloat(data.truck.odometer, 1) + ' &nbsp;km';
	
	// routeadvisor seite1 daten
	data.display = (data.navigation.speedLimit > 0) ? 'block' : 'none';
	
	//tanken in berechnen
		
	if ((data.truck.fuelAverageConsumption) > 0.0 ) {
		data.tanken = 'Refueling in: &nbsp;' + utils.formatFloat(data.truck.fuel, 0) / utils.formatFloat(data.truck.fuelAverageConsumption/100, 0) + ' &nbsp;km';
    } else {
		
        data.tanken = 'Refueling in: &nbsp; wird Berechnet!';
	};
	
	
	
	/*Berrechnen der Distanz in km*/
	data.strecke = 'Route: &nbsp;' + Math.round(data.navigation.estimatedDistance / 1000) + ' &nbsp; km';
	
	/*Berechnung der Vorraussichlichen Ankunftszeit*/
	var jetzt = new Date(data.game.time);
	var estimatedTime = new Date(data.navigation.estimatedTime);
	
	data.ankunft_tag = jetzt.getUTCDay() + estimatedTime.getUTCDay();
	data.ankunft_stunde = jetzt.getUTCHours() + estimatedTime.getUTCHours();
	data.ankunft_minute = jetzt.getUTCMinutes() + estimatedTime.getUTCMinutes();
	
	//data.ankunft_zeit = data.ankunft_tag + data.ankunft_stunde + data.ankunft_minute + data.game.time;
	
	var ankunft = new Date(0000, 00, data.ankunft_tag, data.ankunft_stunde, data.ankunft_minute, 00)
	var ankunft_Tag = ankunft.getUTCDay()-1;
	var ankunft_Wochentag = new Array("So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa.");
	
	data.ankunft_stunde = ankunft.getUTCHours()+1;
	if(data.ankunft_stunde < 10){data.ankunft_stunde = '0' + data.ankunft_stunde;} 
	if(data.ankunft_stunde == 24){data.ankunft_stunde = '00' ;} 
	
	data.ankunft_minute = ankunft.getUTCMinutes()+1;
	if(data.ankunft_minute < 10){data.ankunft_minute = '0' + data.ankunft_minute;} 
		
	data.ankunft =  'Arrivals: &nbsp;' + ankunft_Wochentag[ankunft_Tag] + ' &nbsp; ' + data.ankunft_stunde + ':' + data.ankunft_minute;
	
	/*Formatierung der zeit bis zur nächsten pause*/
	var nextRestStopTimeDate = new Date(data.game.nextRestStopTime);
	var hours = nextRestStopTimeDate.getUTCHours();  	
	var minutes = nextRestStopTimeDate.getUTCMinutes();
	
	data.pause_stunde = nextRestStopTimeDate.getUTCHours();
	if(data.pause_stunde < 10){data.pause_stunde = '0' + data.pause_stunde;} 
	
	data.pause_minute = nextRestStopTimeDate.getUTCMinutes();
	if(data.pause_minute < 10){data.pause_minute = '0' + data.pause_minute;} 
	
	data.pause = 'Next Break: &nbsp;' + data.pause_stunde + ':' + data.pause_minute;

	/*Berechnen der Vorraussichtlichen Fahrzeit*/
	var estimatedTime = new Date(data.navigation.estimatedTime);
	data.zeit_bis_ankunft =  'Time To Arrival: &nbsp;' + ( estimatedTime.getUTCDay() * 24 + estimatedTime.getUTCHours() - 24 )+  '&nbsp; Std. &nbsp;' + ( estimatedTime.getUTCMinutes() + 1 ) + '&nbsp; Min.';
	
	//job-income Formatierung
	data.job.income = data.job.income + ',- €';
	
	// Berechnung der Fracht Anlieferungs Zeit
	var erwartet = new Date(data.job.deadlineTime)
	var erwartet_tag = erwartet.getUTCDay();
	var erwartet_wochentag = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
	
	data.erwartet_stunde = erwartet.getUTCHours();
	if(data.erwartet_stunde < 10){data.erwartet_stunde = '0' + data.erwartet_stunde;} 
	if(data.ankunft_stunde == 24){data.erwartet_stunde = '00' ;}
	
	data.erwartet_minute = erwartet.getUTCMinutes();
	if(data.erwartet_minute < 10){data.erwartet_minute = '0' + data.erwartet_minute;} 
	
	data.deadlineTime = erwartet_wochentag[erwartet_tag]  + data.erwartet_stunde + ':' + data.erwartet_minute;
	
	/*Formatierung für LKW Info Tabelle*/
	
	data.truck.fuelCapacity = 'max. &nbsp;' + data.truck.fuelCapacity + 'L';
	data.truck.adblueCapacity = 'max. &nbsp;' + data.truck.adblueCapacity + 'L';
	
	/*oberes progr. feld*/
	data.oberes_progr_feld_adblueverbrauch_text = utils.formatFloat(data.truck.adblue, 1);
	
	/*unteres progr.feld*/
	data.kraftstoffverbrauch_ave = utils.formatFloat(data.truck.fuel, 1);
	data.teilstreck_tot = utils.formatFloat(data.truck.fuel, 0) / utils.formatFloat(data.truck.fuelAverageConsumption, 0);
	data.teilstreck_ave = data.truck.speed;
	
    // return changed data to the core for rendering
    return data;
};

Funbit.Ets.Telemetry.Dashboard.prototype.render = function (data, utils) {
    //
    // data - same data object as in the filter function
    // utils - an object containing several utility functions (see skin tutorial for more information)
    //
	
	
	$('#systemdruckLine1').css('width', (data.truck.airPressure * 100 /140) + '%');
	$('#systemdruckLine2').css('width', (data.truck.airPressure * 10 /14) + '%');
	
	$('#oberes_progr_feld_kraftstoffverbrauch_Line1').css('width', (data.verbrauch * 100)  + '%' );
	$('#oberes_progr_feld_adblueverbrauch_Line1').css('width', (data.truck.adblue) + '%' ); 
	
	$('.verkehrszeichen').css('display', data.display);
	
	
	$('.trailer_schaden').css('height', (data.trailer.wear * 172 / 100) + 'px');
	
	
    // we don't have anything custom to render in this skin,
    // but you may use jQuery here to update DOM or CSS
};

//funktion um das menü zu versteken
function toggle_visibility(id) {
   var e = document.getElementById(id);
   if(e.style.display == 'block')
	  e.style.display = 'none';
   else
	  e.style.display = 'block';
}

 
function showTab(tabName) {
    // Hide all tabs (map, cargo, damage, about)
    $('#routadvisor1').hide();
	$('#routadvisor2').hide();
    $('#info1').hide();
    $('#einstellung1').hide();
    $('#warnung').hide();
    $('#einstellung2').hide();
    $('#einstellung3').hide();
    $('#lkwinfo1').hide();
    $('#lkwinfo2').hide();
    $('#lkwinfo3').hide();
    $('#lkwinfo4').hide();
    $('#lkwinfo5').hide();
    $('#lkwinfo6').hide();
    $('#lkwinfo7').hide();
    $('#lkwinfo8').hide();
    
    // Remove the "_footerSelected" class from all items.
    $('#routadvisor1').removeClass('_displaySelected');
    $('#routadvisor2').removeClass('_displaySelected');
    $('#info1').removeClass('_displaySelected');
    $('#einstellung1').removeClass('_displaySelected');
    $('#warnung').removeClass('_displaySelected');
    $('#einstellung2').removeClass('_displaySelected');
    $('#einstellung3').removeClass('_displaySelected');
    $('#lkwinfo1').removeClass('_displaySelected');
    $('#lkwinfo2').removeClass('_displaySelected');
    $('#lkwinfo3').removeClass('_displaySelected');
    $('#lkwinfo4').removeClass('_displaySelected');
    $('#lkwinfo5').removeClass('_displaySelected');
    $('#lkwinfo6').removeClass('_displaySelected');
    $('#lkwinfo7').removeClass('_displaySelected');
    $('#lkwinfo8').removeClass('_displaySelected');
    
    // Show the ID requested
    $('#' + tabName).show();
    $('#' + tabName + 'Display').addClass('_displaySelected');
} 

function OberesProgrFeld(tabName) {
    // Hide all tabs (map, cargo, damage, about)
    $('#1').hide();
	$('#2').hide();
    $('#3').hide();
	$('#4').hide();
    $('#5').hide();
	$('#6').hide();
    
    // Remove the "_footerSelected" class from all items.
    $('#1').removeClass('_OberesProgrFeldSelected');
    $('#2').removeClass('_OberesProgrFeldSelected');
    $('#3').removeClass('_OberesProgrFeldSelected');
    $('#4').removeClass('_OberesProgrFeldSelected');
    $('#5').removeClass('_OberesProgrFeldSelected');
    $('#6').removeClass('_OberesProgrFeldSelected');
    
	$('#1' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#2' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#3' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#4' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#5' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#6' + 'kreis_icon').removeClass('_kreis_iconSelected');
	
    // Show the ID requested
    $('#' + tabName).show();
    $('#' + tabName + 'Display').addClass('_displaySelected');
    $('#' + tabName + 'kreis_icon').addClass('_kreis_iconSelected');
	

} 

function UnteresProgrFeld(tabName) {
    // Hide all tabs (map, cargo, damage, about)
    $('#8').hide();
	$('#9').hide();
    $('#10').hide();
	$('#11').hide();
    $('#12').hide();
	$('#13').hide();
    
    // Remove the "_footerSelected" class from all items.
    $('#8').removeClass('_UnteresrogrFeldSelected');
    $('#9').removeClass('_UnteresProgrFeldSelected');
    $('#10').removeClass('_UnteresProgrFeldSelected');
    $('#11').removeClass('_UnteresProgrFeldSelected');
    $('#12').removeClass('_UnteresProgrFeldSelected');
    $('#13').removeClass('_UnteresProgrFeldSelected');
	
    $('#8' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#9' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#10' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#11' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#12' + 'kreis_icon').removeClass('_kreis_iconSelected');
    $('#13' + 'kreis_icon').removeClass('_kreis_iconSelected');
    
    // Show the ID requested
    $('#' + tabName).show();
    $('#' + tabName + 'Display').addClass('_displaySelected');
    $('#' + tabName + 'kreis_icon').addClass('_kreis_iconSelected');
} 

function exit() {
	window.history.back();
	localStorage.setItem('km_inspektion', '2562146.5');
	/* delete localStorage.km_inspektion; */
}
